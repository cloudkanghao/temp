# Custom description of script
#@author Thomas Roth
#@category Ghidra Training
#@menupath AwesomeTools


STACK_RANGE_START = 0x20000000
STACK_RANGE_END = 0x22000000

FLASH_RANGE_START = 0x08000000
FLASH_RANGE_END =   0x08FFFFFF

NUMBER_OF_INTS_TO_CHECK = 10
VALID_VECTOR_TRESHOLD = 6

# - 4 bytes fall into stack range
# - afterwards, MULTIPLE entries fall into flash range

minAddress = currentProgram.memory.minAddress
maxAddress = currentProgram.memory.maxAddress

currentAddress = minAddress

while currentAddress.add(4) < maxAddress:
    int_at_address = currentProgram.memory.getInt(currentAddress)
    if STACK_RANGE_START <= int_at_address <= STACK_RANGE_END:
        print("Address is on stack range! Potential reset vector found")
        


        followingAddress = currentAddress.add(4)
        vector_matches = 0
        for i in range(NUMBER_OF_INTS_TO_CHECK):
            ia = currentProgram.memory.getInt(followingAddress)
            # Is ia in FLASH RANGE, if yes, increase vector matches
            if FLASH_RANGE_START < ia < FLASH_RANGE_END:
                vector_matches += 1

            followingAddress = currentAddress.add(4)

        if vector_matches > VALID_VECTOR_TRESHOLD:
            print("Found potential vector!")
            createBookmark(currentAddress, "vector-finder", "Potential vector")
        # Check if vector matches is above treshold
        # If yes, create a bookmark
        # createBookmark(currentAddress, "vector-finder", "Potential vector")
    currentAddress = currentAddress.add(4)